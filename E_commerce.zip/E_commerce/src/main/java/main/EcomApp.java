package main;

import dao.OrderProcessorRepository;
import dao.OrderProcessorRepositoryImpl;
import exception.CustomerNotFoundException;
import exception.OrderNotFoundException;
import exception.ProductNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import entity.*;
import java.sql.*;

public class EcomApp {
    private static OrderProcessorRepository orderProcessor = new OrderProcessorRepositoryImpl();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean running = true;
        
        while (running) {
            displayMainMenu();
            int choice = getMenuChoice();
            
            try {
                switch (choice) {
                    case 1:
                        registerCustomer();
                        break;
                    case 2:
                        createProduct();
                        break;
                    case 3:
                        deleteProduct();
                        break;
                    case 4:
                        addToCart();
                        break;
                    case 5:
                        viewCart();
                        break;
                    case 6:
                        placeOrder();
                        break;
                    case 7:
                        viewCustomerOrders();
                        break;
                    case 8:
                        viewOrderDetails();
                        break;
                    case 9:
                        cancelOrder();
                        break;
                    case 10:
                        running = false;
                        System.out.println("Exiting application. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (CustomerNotFoundException e) {
                System.out.println("Customer Error: " + e.getMessage());
            } catch (ProductNotFoundException e) {
                System.out.println("Product Error: " + e.getMessage());
            } catch (OrderNotFoundException e) {
                System.out.println("Order Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
                e.printStackTrace();
            }
            
            if (running) {
                System.out.println("\nPress Enter to continue...");
                scanner.nextLine();
            }
        }
        
        scanner.close();
    }

    private static void displayMainMenu() {
        System.out.println("\n===== E-Commerce Application Menu =====");
        System.out.println("1. Register Customer");
        System.out.println("2. Create Product");
        System.out.println("3. Delete Product");
        System.out.println("4. Add to Cart");
        System.out.println("5. View Cart");
        System.out.println("6. Place Order");
        System.out.println("7. View Customer Orders");
        System.out.println("8. View Order Details");
        System.out.println("9. Cancel Order");
        System.out.println("10. Exit");
    }

    private static int getMenuChoice() {
        System.out.print("Enter your choice (1-10): ");
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next();
        }
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        return choice;
    }

    private static void registerCustomer() throws Exception {
        System.out.println("\n--- Register Customer ---");

        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        
        Customer customer = new Customer(0,name, email, password);
        boolean success = orderProcessor.createCustomer(customer);
        
        System.out.println(success ? "Customer registered successfully!" : "Failed to register customer.");
    }

    private static void createProduct() throws Exception {
        System.out.println("\n--- Create Product ---");
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();
        
        System.out.print("Enter description: ");
        String description = scanner.nextLine();
        
        System.out.print("Enter stock quantity: ");
        int stockQuantity = scanner.nextInt();
        scanner.nextLine();
        
        Product product = new Product(0, name, price, description, stockQuantity);
        boolean success = orderProcessor.createProduct(product);
        
        System.out.println(success ? "Product created successfully!" : "Failed to create product.");
    }

    private static void deleteProduct() throws Exception {
        System.out.println("\n--- Delete Product ---");
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        
        boolean success = orderProcessor.deleteProduct(productId);
        
        System.out.println(success ? "Product deleted successfully!" : "Failed to delete product.");
    }

    private static void addToCart() throws Exception {
        System.out.println("\n--- Add to Cart ---");
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();
        
        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        
        Product product = new Product();
        product.setProductId(productId);
        
        boolean success = orderProcessor.addToCart(customer, product, quantity);
        
        System.out.println(success ? "Product added to cart successfully!" : "Failed to add product to cart.");
    }

    private static void viewCart() throws Exception {
        System.out.println("\n--- View Cart ---");
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        
        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        
        List<Product> cartItems = orderProcessor.getAllFromCart(customer);
        
        if (cartItems.isEmpty()) {
            System.out.println("Your cart is empty.");
        } else {
            System.out.println("\nCart Items:");
            System.out.println("----------------------------------------");
            System.out.printf("%-5s %-20s %-10s %-5s%n", "ID", "Name", "Price", "Qty");
            System.out.println("----------------------------------------");
            
            double total = 0;
            for (Product product : cartItems) {
                // Note: In a real app, you would need to get the quantity from the cart
                System.out.printf("%-5d %-20s $%-9.2f %-5d%n", 
                    product.getProductId(), 
                    product.getName(), 
                    product.getPrice(), 
                    1); // Default quantity 1 for display
                total += product.getPrice();
            }
            
            System.out.println("----------------------------------------");
            System.out.printf("%-26s $%-9.2f%n", "Total:", total);
        }
    }

    private static void placeOrder() throws Exception {
        System.out.println("\n--- Place Order ---");
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        
        Customer customer = new Customer();
        customer.setCustomerId(customerId);
        
        // Get cart items
        List<Product> cartItems = orderProcessor.getAllFromCart(customer);
        
        if (cartItems.isEmpty()) {
            System.out.println("Cannot place order - cart is empty.");
            return;
        }
        
        // Display cart items and get quantities
        System.out.println("\nItems in your cart:");
        double total = 0;
        List<Map<Product, Integer>> productsWithQuantities = new ArrayList<>();
        Map<Product, Integer> productQuantityMap = new HashMap<>();
        
        for (Product product : cartItems) {
            System.out.print("Enter quantity for " + product.getName() + 
                           " (max " + product.getStockQuantity() + "): ");
            int quantity = scanner.nextInt();
            scanner.nextLine();
            
            if (quantity > 0 && quantity <= product.getStockQuantity()) {
                productQuantityMap.put(product, quantity);
                total += product.getPrice() * quantity;
            } else {
                System.out.println("Invalid quantity. Using default quantity 1.");
                productQuantityMap.put(product, 1);
                total += product.getPrice();
            }
        }
        
        productsWithQuantities.add(productQuantityMap);
        
        System.out.printf("\nOrder total: $%.2f%n", total);
        System.out.print("Enter shipping address: ");
        String shippingAddress = scanner.nextLine();
        
        // Confirm order
        System.out.print("\nConfirm order (Y/N)? ");
        String confirm = scanner.nextLine();
        
        if (confirm.equalsIgnoreCase("Y")) {
            boolean success = orderProcessor.placeOrder(customer, productsWithQuantities, shippingAddress);
            System.out.println(success ? "Order placed successfully!" : "Failed to place order.");
        } else {
            System.out.println("Order canceled.");
        }
    }

    private static void viewCustomerOrders() throws Exception {
        System.out.println("\n--- View Customer Orders ---");
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();
        
        List<Map<Product, Integer>> orders = orderProcessor.getOrdersByCustomer(customerId);
        
        if (orders.isEmpty()) {
            System.out.println("No orders found for this customer.");
            return;
        }
        
        System.out.println("\nCustomer Orders:");
        int orderNum = 1;
        for (Map<Product, Integer> order : orders) {
            System.out.println("Order #" + orderNum++ + ":");
            System.out.println("----------------------------------------");
            System.out.printf("%-20s %-10s %-5s %-10s%n", "Name", "Price", "Qty", "Total");
            System.out.println("----------------------------------------");
            
            double orderTotal = 0;
            for (Map.Entry<Product, Integer> entry : order.entrySet()) {
                Product product = entry.getKey();
                int quantity = entry.getValue();
                double itemTotal = product.getPrice() * quantity;
                orderTotal += itemTotal;
                
                System.out.printf("%-20s $%-9.2f %-5d $%-9.2f%n",
                    product.getName(), product.getPrice(), quantity, itemTotal);
            }
            
            System.out.println("----------------------------------------");
            System.out.printf("%-36s $%-9.2f%n%n", "Order Total:", orderTotal);
        }
    }

    private static void viewOrderDetails() throws Exception {
        System.out.println("\n--- View Order Details ---");
        System.out.print("Enter order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine();
        
        Order order = orderProcessor.getOrderById(orderId);
        List<OrderItem> orderItem = orderProcessor.getOrderItemsByOrderId(orderId);
        
        System.out.println("\nOrder Details:");
        System.out.println("Order ID: " + order.getOrderId());
        System.out.println("Order Date: " + order.getOrderDate());
        System.out.println("Shipping Address: " + order.getShippingAddress());
        System.out.printf("Total Price: $%.2f%n", order.getTotalPrice());
        
        System.out.println("\nOrder Items:");
        System.out.println("----------------------------------------");
        System.out.printf("%-20s %-10s %-5s %-10s%n", "Name", "Price", "Qty", "Total");
        System.out.println("----------------------------------------");
        
        for (OrderItem item : orderItem) {
            Product product = getProductById(item.getProductId());
            System.out.printf("%-20s $%-9.2f %-5d $%-9.2f%n",
                product.getName(), product.getPrice(), item.getQuantity(),
                product.getPrice() * item.getQuantity());
        }
        
        System.out.println("----------------------------------------");
    }

    private static void cancelOrder() throws Exception {
        System.out.println("\n--- Cancel Order ---");
        System.out.print("Enter order ID to cancel: ");
        int orderId = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Are you sure you want to cancel this order (Y/N)? ");
        String confirm = scanner.nextLine();
        
        if (confirm.equalsIgnoreCase("Y")) {
            boolean success = orderProcessor.cancelOrder(orderId);
            System.out.println(success ? "Order canceled successfully." : "Failed to cancel order.");
        } else {
            System.out.println("Order cancellation aborted.");
        }
    }

    private static Product getProductById(int productId) throws Exception {
        // In a real implementation, this would use a DAO method
        // Simplified for this example
        String query = "SELECT * FROM products WHERE product_id = ?";
        try (Connection conn = orderProcessor.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, productId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new Product(
                    rs.getInt("product_id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getString("description"),
                    rs.getInt("stockQuantity")
                );
            }
            throw new ProductNotFoundException("Product with ID " + productId + " not found.");
        }
    }
}