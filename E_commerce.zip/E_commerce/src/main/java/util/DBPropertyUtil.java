package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getPropertyString(String propertyFileName) throws IOException {
        Properties properties = new Properties();
        try (InputStream input = DBPropertyUtil.class.getClassLoader().getResourceAsStream(propertyFileName)) {
            if (input == null) {
                throw new IOException("Unable to find " + propertyFileName);
            }
            properties.load(input);
            
            String hostname = properties.getProperty("hostname");
            String dbname = properties.getProperty("dbname");
            String username = properties.getProperty("username");
            String password = properties.getProperty("password");
            String port = properties.getProperty("port");
            
            return "jdbc:mysql://" + hostname + ":" + port + "/" + dbname + 
                   "?user=" + username + "&password=" + password;
        }
    }
}
