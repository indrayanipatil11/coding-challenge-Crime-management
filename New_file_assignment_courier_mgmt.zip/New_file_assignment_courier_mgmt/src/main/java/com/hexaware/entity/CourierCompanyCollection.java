package com.hexaware.entity;

import java.util.List;

public class CourierCompanyCollection {

	// Task 8.1 Creation of CourierCOmpanyCollection

	// Variables companyName ,
	// courierDetails -collection of Courier Objects,
	// employeeDetails- collection of Employee Objects,
	// locationDetails - collection of Location Objects.

	private String companyName;
	private List<Courier> courierDetails;
	private List<Employee> employeeDetails;
	private List<Location> locationDetails;

	public CourierCompanyCollection() {

	}

	public CourierCompanyCollection(String companyName, List<Courier> courierDetails, List<Employee> employeeDetails,
			List<Location> locationDetails) {
		this.companyName = companyName;
		this.courierDetails = courierDetails;
		this.employeeDetails = employeeDetails;
		this.locationDetails = locationDetails;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {

		this.companyName = companyName;
	}

	public List<Courier> getCourierDetails() {
		return courierDetails;
	}

	public void setCourierDetails(List<Courier> courierDetails) {
		this.courierDetails = courierDetails;
	}

	public List<Employee> getEmployeeDetails() {
		return employeeDetails;
	}

	public void setEmployeeDetails(List<Employee> employeeDetails) {
		this.employeeDetails = employeeDetails;
	}

	public List<Location> getLocationDetails() {
		return locationDetails;
	}

	public void setLocationDetails(List<Location> locationDetails) {
		this.locationDetails = locationDetails;
	}

	public String toString() {
		return "Courier Company: " + "Company Name: '" + companyName + ", Courier Details: " + courierDetails
				+ ", Employee Details=" + employeeDetails + ", Location Details=" + locationDetails;
	}
}
