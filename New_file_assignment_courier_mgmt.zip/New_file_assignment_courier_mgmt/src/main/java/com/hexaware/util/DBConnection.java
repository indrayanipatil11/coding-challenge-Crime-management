package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	// Task 9.1 Establishing connection to Database

	static Connection connection;

	public static Connection getConnection() {
		try {
			connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/courier_data", "root",
					"Hexaware@12345");

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return connection;
	}

	public static void main(String[] args) {
		System.out.println(getConnection());

	}

}
