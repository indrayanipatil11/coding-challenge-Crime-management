package com.hexaware.dao;

import com.hexaware.entity.CourierCompanyCollection;

// Task 8.3 

public class CourierAdminServiceCollectionImpl extends CourierUserServiceCollectionImpl
		implements ICourierAdminService {
	public CourierAdminServiceCollectionImpl(CourierCompanyCollection companyObj) {
		super(companyObj);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addCourierStaff() {
		// TODO Auto-generated method stub
	}

	@Override
	public void viewEmployee() {
		// TODO Auto-generated method stub
	}

	@Override
	public void viewAllOrders() {
		// TODO Auto-generated method stub

	}

	@Override
	public void showAssignedOrders(int employeeId) {
		// TODO Auto-generated method stub

	}

	@Override
	public void generateReport() {
		// TODO Auto-generated method stub
		
	}
}
