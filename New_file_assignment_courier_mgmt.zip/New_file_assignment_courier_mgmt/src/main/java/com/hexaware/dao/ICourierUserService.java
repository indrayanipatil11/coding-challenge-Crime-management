package com.hexaware.dao;

import com.hexaware.entity.Courier;
import com.hexaware.exception.TrackingNumberNotFoundException;

import java.sql.SQLException;

public interface ICourierUserService {

	// Task 6 Courier User Service

	public String placeOrder(Courier cr);

	public void courierDetails();

	public String getOrderStatus(String trackingNumber) throws TrackingNumberNotFoundException, SQLException;

	public boolean cancelOrder(String trackingNumber) throws TrackingNumberNotFoundException;

	public void showOrders();

}
